package SolutionsAndTests.CS_DS.u0.ChallengeSet2;

import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;

public class Bank_Tests
{
    public String generateClassName(String name)
    {
        if(getClass().toString().contains("."))
        {
            return getClass().toString().substring(6,getClass().toString().lastIndexOf(".")+1)+name;
        }
        return name;
    }

    @Test
    public void test1() throws Exception {

        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Bank of Scrooge McDuck");


        Method getName = classRef.getMethod("getName");
        Method getAccounts = classRef.getMethod("getAccounts");

        Assert.assertEquals("Bank of Scrooge McDuck",getName.invoke(bank));

        ArrayList accounts = (ArrayList) getAccounts.invoke(bank);
        Assert.assertNotNull(accounts);
        Assert.assertEquals(0,accounts.size());
    }

    @Test
    public void test2() throws Exception {

        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Dimes and Quarters");


        Method getName = classRef.getMethod("getName");
        Method getAccounts = classRef.getMethod("getAccounts");

        Assert.assertEquals("Dimes and Quarters",getName.invoke(bank));
        ArrayList accounts =  (ArrayList) getAccounts.invoke(bank);
        Assert.assertNotNull(accounts);
        Assert.assertEquals(0,accounts.size());
    }

    @Test
    public void test3() throws Exception {

        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Bank of Scrooge McDuck");


        Method getName = classRef.getMethod("getName");
        Method setName = classRef.getMethod("setName",String.class);

        setName.invoke(bank,"Turtles");
        Assert.assertEquals("Turtles",getName.invoke(bank));

    }

    @Test
    public void test4() throws Exception {

        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Bank of Scrooge McDuck");


        Method getName = classRef.getMethod("getName");
        Method setName = classRef.getMethod("setName",String.class);

        setName.invoke(bank,"Money Town");
        Assert.assertEquals("Money Town",getName.invoke(bank));

    }

    @Test
    public void test5() throws Exception {
        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Class<?> accountRef = Class.forName(generateClassName("Account"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Piggy's Bank");


        Method openAccount = classRef.getMethod("openAccount",long.class,String.class,double.class);
        Method getAccounts = classRef.getMethod("getAccounts");
        Method getAccount = classRef.getMethod("getAccount", long.class);

        Method getAccountNumber = accountRef.getMethod("getAccountNumber");
        Method getCustomerName = accountRef.getMethod("getCustomerName");
        Method getBalance = accountRef.getMethod("getBalance");

        Assert.assertEquals(true,openAccount.invoke(bank,12345678L,"Billy Smith",3500.98));
        Assert.assertEquals(true,openAccount.invoke(bank,14287569L,"Jane Long",99999.53));
        Assert.assertEquals(true,openAccount.invoke(bank,44458765L,"Lisa Turtle",87596.66));

        ArrayList accounts = (ArrayList)getAccounts.invoke(bank);
        Assert.assertNotNull(accounts);
        Assert.assertEquals(3,accounts.size());

        Account account1 = (Account) getAccount.invoke(bank,12345678);
        Assert.assertNotNull(account1);
        Assert.assertEquals(12345678L,(long)getAccountNumber.invoke(account1));
        Assert.assertEquals("Billy Smith",getCustomerName.invoke(account1));
        Assert.assertEquals(3500.98,(double)getBalance.invoke(account1),.001);

        Account account2 = (Account) getAccount.invoke(bank,14287569L);
        Assert.assertNotNull(account2);
        Assert.assertEquals(14287569L,(long)getAccountNumber.invoke(account2));
        Assert.assertEquals("Jane Long",getCustomerName.invoke(account2));
        Assert.assertEquals(99999.53,(double)getBalance.invoke(account2),.001);

        Account account3 = (Account) getAccount.invoke(bank,44458765L);
        Assert.assertNotNull(account3);
        Assert.assertEquals(44458765L,(long)getAccountNumber.invoke(account3));
        Assert.assertEquals("Lisa Turtle",getCustomerName.invoke(account3));
        Assert.assertEquals(87596.66,(double)getBalance.invoke(account3),.001);
    }

    @Test
    public void test6() throws Exception {
        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Piggy's Bank");


        Method openAccount = classRef.getMethod("openAccount",long.class,String.class,double.class);

        Assert.assertEquals(false,openAccount.invoke(bank,12345678L,"Billy Smith",-20));
    }

    @Test
    public void test7() throws Exception {
        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Piggy's Bank");


        Method openAccount = classRef.getMethod("openAccount",long.class,String.class,double.class);

        Assert.assertEquals(false,openAccount.invoke(bank,12345678L,"Billy Smith",0));
    }

    @Test(timeout = 250)
    public void test8() throws Exception {
        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Piggy's Bank");


        Method openAccount = classRef.getMethod("openAccount",long.class,String.class,double.class);

        Assert.assertEquals(true,openAccount.invoke(bank,12345678L,"Billy Smith",134));
        Assert.assertEquals(false,openAccount.invoke(bank,12345678L,"James Smith",4444));
    }



    @Test(timeout = 250)
    public void test9() throws Exception {
        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Object bank = classRef.getConstructor(String.class).newInstance
                ("Piggy's Bank");

        Method openAccount = classRef.getMethod("openAccount", long.class, String.class, double.class);
        Method getAccount = classRef.getMethod("getAccount", long.class);

        openAccount.invoke(bank, 12345678L, "Billy Smith", 589);

        Assert.assertNull(getAccount.invoke(bank, 14277569L));
    }

    @Test(timeout = 250)
    public void test10() throws Exception {
        Class<?> classRef = Class.forName(generateClassName("Bank"));
        Class<?> accountRef = Class.forName(generateClassName("Account"));

        Object bank = classRef.getConstructor(String.class).newInstance
                ("Piggy's Bank");

        Method openAccount = classRef.getMethod("openAccount", long.class, String.class, double.class);
        Method getAccount = classRef.getMethod("getAccount", long.class);
        Method getAccounts = classRef.getMethod("getAccounts");
        Method closeAccount = classRef.getMethod("closeAccount", long.class);

        openAccount.invoke(bank, 12345678L, "Billy Joe", 111.11);
        openAccount.invoke(bank, 12299999L, "Alex Smith", 222.22);
        openAccount.invoke(bank, 33333333L, "Jane Timith", 333.33);

        Assert.assertEquals(222.22,(double)closeAccount.invoke(bank,12299999L),.001);

        ArrayList accounts = (ArrayList)getAccounts.invoke(bank);
        Assert.assertNotNull(accounts);
        Assert.assertEquals(2,accounts.size());

        Method getAccountNumber = accountRef.getMethod("getAccountNumber");
        Method getCustomerName = accountRef.getMethod("getCustomerName");
        Method getBalance = accountRef.getMethod("getBalance");

        Object account1 = getAccount.invoke(bank,12345678L);
        Assert.assertNotNull(account1);
        Assert.assertEquals(12345678L,(long)getAccountNumber.invoke(account1));
        Assert.assertEquals("Billy Joe",getCustomerName.invoke(account1));
        Assert.assertEquals(111.11,(double)getBalance.invoke(account1),.001);

        Account account2 = (Account) getAccount.invoke(bank,12299999L);
        Assert.assertNull(account2);

        Account account3 = (Account) getAccount.invoke(bank,33333333L);
        Assert.assertNotNull(account3);
        Assert.assertEquals(33333333L,(long)getAccountNumber.invoke(account3));
        Assert.assertEquals("Jane Timith",getCustomerName.invoke(account3));
        Assert.assertEquals(333.33,(double)getBalance.invoke(account3),.001);

    }

/*

    // Close account correct
    @Test
    public void test7() throws Exception {

            String bN = "Bank of Scrooge McDuck";
            Bank bank = new Bank(bN);

            Assert.assertEquals("openAccount(12345678,\"Billy Smith\",3500.98) failed to return true, when the account number was not already used.", bank.openAccount(12345678L,"Billy Smith",3500.98));
            Assert.assertEquals("openAccount(14287569,\"Jane Long\",99999.53) failed to return true, when the account number was not already used.", bank.openAccount(14287569L,"Jane Long",99999.53));
            Assert.assertEquals("openAccount(44458765,\"Lisa Turtle\",87596.66) failed to return true, when the account number was not already used.", bank.openAccount( 44458765L,"Lisa Turtle",87596.66));

            Assert.assertNotNull("getAccounts() returned null after creating a bank with Bank("+bN+")",bank.getAccounts());
            Assert.assertEquals("getAccounts().size() failed after creating a bank with Bank("+bN+") and then opening 3 unique accouts.",3,bank.getAccounts().size());

            double acc = bank.closeAccount(12345678);
            Assert.assertEquals("closeAccounts(12345678) failed return the correct balance of the closed account.",3500.98,acc,.001);
            Assert.assertEquals("getAccounts().size() failed after creating a bank with Bank("+bN+"), then opening 3 unique accouts and finally closing 1 account",2,bank.getAccounts().size());

            Assert.assertNotNull("getAccounts().getAccount("+14287569+") returned null for a valid account",bank.getAccount(14287569));
            Assert.assertEquals("getAccounts().getAccount("+14287569+").getAccountNumber() returned an account with the wrong account number",14287569,(long)bank.getAccount(14287569).getAccountNumber());
            Assert.assertEquals("getAccounts().getAccount("+14287569+").getCustomerName() returned an account with the wrong customer name.","Jane Long",bank.getAccount(14287569).getCustomerName());
            Assert.assertEquals("getAccounts().getAccount("+14287569+").getBalance() returned an account with an incorrect balance.",99999.53,bank.getAccount(14287569).getBalance(),.001);

            Assert.assertNotNull("getAccounts().getAccount("+44458765L+") returned null for a valid account",bank.getAccount(44458765L));
            Assert.assertEquals("getAccounts().getAccount("+44458765L+").getAccountNumber() returned an account with the wrong account number",44458765L,(long)bank.getAccount(44458765L).getAccountNumber());
            Assert.assertEquals("getAccounts().getAccount("+44458765L+").getCustomerName() returned an account with the wrong customer name.","Lisa Turtle",bank.getAccount(44458765L).getCustomerName());
            Assert.assertEquals("getAccounts().getAccount("+44458765L+").getBalance() returned an account with an incorrect balance.",87596.66,bank.getAccount(44458765L).getBalance(),.001);
    }
    */

}
